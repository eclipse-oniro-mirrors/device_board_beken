#include <stdio.h>
#include <board.h>
#include "BK_System.h"
#include "los_context.h"
#include "los_task.h"


VOID TaskSampleEntry2(VOID)
{
    while (1) {
        LOS_TaskDelay(10); /* 10 Seconds */
        bk_printf("TaskSampleEntry2 running...\r\n");
    }
}

VOID TaskSampleEntry1(VOID)
{
    while (1) {
        LOS_TaskDelay(50); /* 2 Seconds */
        bk_printf("TaskSampleEntry1 running...\r\n");
    }
}

