#include <stdio.h>
#include <board.h>
#include "BK_System.h"
#include "los_context.h"
#include "los_task.h"

#if ((CFG_SOC_NAME == SOC_BK7231N) || (CFG_SOC_NAME == SOC_BK7236))
unsigned int bk72 __attribute__((at(0x100))) = (0x32374B42);
unsigned int b31  __attribute__((at(0x104))) = (0x00003133);
#endif

#if (CFG_SOC_NAME == SOC_BK7271)
const unsigned int bk7271[2] __attribute__((at(0x100)))={0x32374B42,0x00003137};
#endif

void gpio_13_high()
{
    REG_WRITE((0x0802800 +(13*4)),(0x2));
}

extern int uart_init(void);
extern UINT32 g_spPtr;
extern void uart_console_output(const char *str, int length);
extern char *__irq_stack_top;
void test_print(UINT32 arg, UINT32 arg1)
{
    //uart_putc('@');
    char buf[256] = {0};
    UINT32 *reg = (UINT32 *)arg;

    //sprintf(buf, "@@@@@ %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x, %x\r\n", reg[0], reg[1],reg[2],reg[3],reg[4],reg[5],reg[6],
        //reg[7],reg[8],reg[9],reg[10],reg[11],reg[12],reg[13],reg[14],reg[15], arg1);
    sprintf(buf, "arg: %x, arg: %x, arg: %x\r\n", arg, arg1, &__irq_stack_top);
    bk_printf(buf);
}

void test_print1(void)
{
    bk_printf("+++++++\r\n");
}

void test_print2(void)
{
    bk_printf("~~~~~\r\n");
}

void test_print3(void)
{
    bk_printf("-------\r\n");
}

//gpio pin_no output high
void gpio_output_high(u8 pin_no)
{
    REG_WRITE((0x0802800 +(pin_no << 2)),2);
}

// //gpio pin_no output low
void gpio_output_low(u8 pin_no)
{
    REG_WRITE((0x0802800 +(pin_no << 2)),0);
}

extern VOID TaskSampleEntry1(VOID);
extern VOID TaskSampleEntry2(VOID);

VOID TaskSample(VOID)
{
    UINT32 uwRet;
    UINT32 taskID1;
    UINT32 taskID2;
    TSK_INIT_PARAM_S stTask = {0};

    stTask.pfnTaskEntry = (TSK_ENTRY_FUNC)TaskSampleEntry1;
    stTask.uwStackSize = 0x1000;
    stTask.pcName = "TaskSampleEntry1";
    stTask.usTaskPrio = 6; /* Os task priority is 6 */
    uwRet = LOS_TaskCreate(&taskID1, &stTask);
    if (uwRet != LOS_OK) {
        printf("Task1 create failed\n");
    }

    stTask.pfnTaskEntry = (TSK_ENTRY_FUNC)TaskSampleEntry2;
    stTask.uwStackSize = 0x1000;
    stTask.pcName = "TaskSampleEntry2";
    stTask.usTaskPrio = 7; /* Os task priority is 7 */
    uwRet = LOS_TaskCreate(&taskID2, &stTask);
    if (uwRet != LOS_OK) {
        printf("Task2 create failed\n");
    }
}

unsigned int g_intSave;
int main(void)
{
#if (CFG_SOC_NAME == SOC_BK7221U)
    // for fix bk7221u reset
    gpio_13_high();
#endif

    (void)LOS_IntLock();
    intc_forbidden_all();
    int_init();
    rt_hw_board_init();

    extern unsigned int HalTickStart(OS_TICK_HANDLER *handler);
    reset_timer();
    intc_start();

    unsigned int count;
    unsigned int delay_count = 100000;
    while (delay_count > 0) {
        uart_putc('!');
        delay_count--;
        for (count = 0; count < 10000000; count++) {};
    }

    LOS_KernelInit();

    TaskSample();

    LOS_Start();

    while (1) {
    }

	return 0;
}


struct reset_register
{
    uint32_t cpsr;
    uint32_t r0;
    uint32_t r1;
    uint32_t r2;
    uint32_t r3;
    uint32_t r4;
    uint32_t r5;
    uint32_t r6;
    uint32_t r7;
    uint32_t r8;
    uint32_t r9;
    uint32_t r10; // sl stack limit
    uint32_t r11; // fp frame pointer
    uint32_t r12; // ip Intra-Procedure-call scratch register
    uint32_t r13; // sp Stack Pointer.
    uint32_t r14; // lr Link Register.
};


void reset_register_dump(void)
{
    const struct reset_register *reg = (const struct reset_register *)0x400020;
    #if (CFG_SOC_NAME == SOC_BK7221U)
    bk_printf("BK7251");
    #elif(CFG_SOC_NAME == SOC_BK7231U)
    bk_printf("BK7231u");
    #elif(CFG_SOC_NAME == SOC_BK7231N)
    bk_printf("BK7231n");
    #elif(CFG_SOC_NAME == SOC_BK7271)
    bk_printf("BK7271");
    #elif(CFG_SOC_NAME == SOC_BK7236)
    bk_printf("BK7236");
    #else
    bk_printf("BK7231");
    #endif
    bk_printf("_1.0.8");
    bk_printf("\r\nCPSR:");
    bk_print_hex(reg->cpsr);
    bk_printf("\r\nR0:");
    bk_print_hex(reg->r0);
    bk_printf("\r\nR1:");
    bk_print_hex(reg->r1);
    bk_printf("\r\nR2:");
    bk_print_hex(reg->r2);
    bk_printf("\r\nR3:");
    bk_print_hex(reg->r3);
    bk_printf("\r\nR4:");
    bk_print_hex(reg->r4);
    #if 0
    bk_printf("\r\nR5:");
    bk_print_hex(reg->r5);
    bk_printf("\r\nR6:");
    bk_print_hex(reg->r6);
    bk_printf("\r\nR7:");
    bk_print_hex(reg->r7);
    bk_printf("\r\nR8:");
    bk_print_hex(reg->r8);
    bk_printf("\r\nR9:");
    bk_print_hex(reg->r9);
    bk_printf("\r\nR10:");
    bk_print_hex(reg->r10);
    bk_printf("\r\nR11:");
    bk_print_hex(reg->r11);
    bk_printf("\r\nR12:");
    bk_print_hex(reg->r12);
    #endif
    bk_printf("\r\nR13:");
    bk_print_hex(reg->r13);
    bk_printf("\r\nR14(LR):");
    bk_print_hex(reg->r14);
    bk_printf("\r\nST:");
    bk_print_hex(*((uint32_t *)START_TYPE_ADDR));
    bk_printf("\r\n");
}
